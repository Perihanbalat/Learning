# Plinth
For team Plinth at S2DS Oct 2019
